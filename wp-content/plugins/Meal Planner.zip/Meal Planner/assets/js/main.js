jQuery(document).ready(function() {
    jQuery('#usersTable').DataTable();
} );